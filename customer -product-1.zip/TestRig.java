

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class TestRig.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class TestRig
{
    private Product product1;
    private OrderLine orderLin1;
    private Order order1;
    private Customer customer1;

    /**
     * Default constructor for test class TestRig
     */
    public TestRig()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        product1 = new Product(1, "R�dvin", 66, 48);
        orderLin1 = new OrderLine(6, product1);
        order1 = new Order(1, "29-09-2020", "29-09-2020");
        order1.setOrderLine(orderLin1);
        customer1 = new Customer(1, "Ib", "Bygaden 20", "12345678");
        customer1.setOrder(order1);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
