/**
 * @author (Kis Boisen Hansen - FEN) 
 * @version (2010.09.23 - 2019.09.13)
 */
public class Order{
    private int number;
    private String orderDate;
    private String deliveryDate;
    private String payDate;
    private boolean status;
    private OrderLine myOrderLine;// at the moment only one partorder pr. order

    public Order(int number, String orderDate, String deliveryDate){
        this.number = number;
        this.orderDate = orderDate;
        this.deliveryDate = deliveryDate;
        this.status = false;
        this.myOrderLine = null; 
       
    }
    
    public OrderLine getOrder(){
        return myOrderLine;
    }
    
    public void setOrderLine(OrderLine newLine){
        myOrderLine = newLine;
    }

    public void printInfo(){
        System.out.println("Ordrenummer: " + number + " Orderdato: "
                    + orderDate);
        //print info about order line(s)
        myOrderLine.printInfo();
    }
}
